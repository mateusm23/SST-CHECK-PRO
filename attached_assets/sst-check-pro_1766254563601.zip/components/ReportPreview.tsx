
import React from 'react';
import { InspectionData } from '../types';
import { CHECKLISTS } from '../constants';

interface ReportPreviewProps {
  data: InspectionData;
  onNew: () => void;
}

const ReportPreview: React.FC<ReportPreviewProps> = ({ data, onNew }) => {
  const checklist = CHECKLISTS[data.checklistId];
  const dateStr = new Date(data.data).toLocaleDateString('pt-BR');
  const timeStr = new Date(data.data).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

  const stats = {
    total: Object.keys(data.respostas).length,
    ok: Object.values(data.respostas).filter(r => r.status === 'ok').length,
    nc: Object.values(data.respostas).filter(r => r.status === 'nc').length,
    na: Object.values(data.respostas).filter(r => r.status === 'na').length,
  };

  const conformidade = stats.total - stats.na > 0 
    ? Math.round((stats.ok / (stats.total - stats.na)) * 100) 
    : 100;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="pb-20 space-y-8 animate-in fade-in duration-700">
      {/* Action Bar */}
      <div className="flex flex-wrap gap-4 no-print bg-white p-6 rounded-3xl border border-slate-200 shadow-xl">
         <button 
           onClick={handlePrint} 
           className="bg-[#FFD100] text-[#1A1D23] px-8 py-4 rounded-2xl font-bold uppercase text-xs tracking-widest shadow-lg hover:bg-[#E6BC00] active:scale-95 transition-all flex items-center gap-2"
         >
           📥 Salvar Relatório (PDF)
         </button>
         <button 
           onClick={onNew} 
           className="bg-slate-100 text-slate-600 px-8 py-4 rounded-2xl font-bold uppercase text-xs tracking-widest hover:bg-slate-200 active:scale-95 transition-all"
         >
           + Nova Inspeção
         </button>
      </div>

      {/* Actual Report Content */}
      <div className="bg-white text-slate-900 rounded-3xl overflow-hidden shadow-2xl print:shadow-none print:m-0 print:rounded-none border border-slate-100">
         {/* Header PDF */}
         <div className="bg-[#1A1D23] text-white p-10 flex justify-between items-center border-b-[6px] border-[#FFD100]">
            <div>
               <div className="flex items-center gap-4 mb-3">
                  <div className="w-10 h-10 bg-[#FFD100] rounded-xl flex items-center justify-center font-bold text-[#1A1D23] text-xl">✓</div>
                  <span className="font-bebas text-3xl tracking-wider">SST<span className="text-[#FFD100]">CHECK</span>PRO</span>
               </div>
               <div className="text-[10px] text-slate-400 uppercase font-bold tracking-[.3em]">Relatório Técnico de Inspeção</div>
            </div>
            <div className="text-right">
               <div className="text-[#FFD100] font-bebas text-3xl">L-#{data.id.slice(-6)}</div>
               <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Pág. 01 / 01</div>
            </div>
         </div>

         <div className="p-10">
            {/* Project Info */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8 mb-12 text-sm">
               <InfoItem label="Obra / Canteiro" value={data.obra} />
               <InfoItem label="Empresa Cliente" value={data.cliente || 'Consumidor Final'} />
               <InfoItem label="Data da Visita" value={`${dateStr} às ${timeStr}`} />
               <InfoItem label="Técnico Responsável" value={data.responsavel} />
               <InfoItem label="Cargo / Registro" value={`${data.cargo || 'N/I'} • ${data.registro || 'S/R'}`} />
               <InfoItem label="Status Final" value={conformidade >= 80 ? 'APROVADO' : 'PENDENTE'} highlight={conformidade < 80} />
            </div>

            {/* Stats Summary */}
            <div className="grid grid-cols-4 gap-4 mb-16">
               <StatBox label="Itens Vistoriados" val={stats.total} color="bg-slate-50 border border-slate-100" />
               <StatBox label="Conformidades" val={stats.ok} color="bg-green-50 text-green-700 border border-green-100" />
               <StatBox label="Não Conf." val={stats.nc} color="bg-red-50 text-red-700 border border-red-100" />
               <StatBox label="Grau de Conformidade" val={`${conformidade}%`} color="bg-[#FFD100]/10 text-[#1A1D23] border border-[#FFD100]/20" />
            </div>

            {/* Non-Conformities & Action Plans */}
            {stats.nc > 0 && (
              <div className="mb-16">
                 <div className="flex items-center gap-3 mb-8 border-b-2 border-slate-100 pb-3">
                    <span className="w-3 h-3 rounded-full bg-red-500"></span>
                    <h3 className="font-bebas text-2xl text-slate-900 tracking-widest uppercase">Plano de Ação Corretiva</h3>
                 </div>
                 <div className="space-y-8">
                    {Object.entries(data.respostas).filter(([_, r]) => r.status === 'nc').map(([idx, r], ncIdx) => {
                      const questionIdx = parseInt(idx);
                      let questionText = "";
                      let currentCount = 0;
                      checklist.sections.forEach(s => s.items.forEach(item => {
                         if (currentCount === questionIdx) questionText = item;
                         currentCount++;
                      }));

                      return (
                        <div key={ncIdx} className="border border-slate-200 rounded-3xl p-8 bg-slate-50/50 page-break-inside-avoid">
                           <div className="flex justify-between items-start mb-6">
                              <p className="font-bold text-slate-800 flex-1 pr-6 leading-tight"><span className="text-red-500 mr-2">{ncIdx + 1}.</span> {questionText}</p>
                              <span className="text-[10px] font-bold text-red-600 uppercase bg-red-100 px-3 py-1 rounded-full">Não Conforme</span>
                           </div>
                           
                           {r.observation && (
                             <div className="mb-6 bg-white p-4 rounded-xl border border-slate-100">
                                <span className="text-[9px] font-bold text-slate-400 uppercase block mb-1">Parecer Técnico:</span>
                                <p className="text-xs text-slate-600 font-medium italic">"{r.observation}"</p>
                             </div>
                           )}
                           
                           {r.photos.length > 0 && (
                             <div className="flex gap-4 mb-6">
                                {r.photos.map((p, pIdx) => (
                                  <img key={pIdx} src={p} className="w-32 h-32 rounded-2xl object-cover border-4 border-white shadow-lg" alt="Evidência" />
                                ))}
                             </div>
                           )}

                           <div className="bg-white p-6 rounded-2xl border-2 border-red-50 shadow-sm">
                              <div className="text-[10px] font-bold text-red-500 uppercase mb-3 tracking-widest">Ação Corretiva Recomendada</div>
                              <p className="text-sm font-bold text-slate-700 mb-4">{r.actionPlan?.responsible || 'Regularização imediata conforme norma.'}</p>
                              <div className="flex gap-10 text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                                 <div><span className="text-slate-300 mr-2">PRAZO:</span> <span className="text-slate-900">{r.actionPlan?.deadline || 'IMEDIATO'}</span></div>
                                 <div><span className="text-slate-300 mr-2">URGÊNCIA:</span> <span className="text-slate-900">{r.actionPlan?.priority || 'MÉDIA'}</span></div>
                              </div>
                           </div>
                        </div>
                      )
                    })}
                 </div>
              </div>
            )}

            {/* Verification Items Table */}
            <div className="page-break-before-auto">
               <h3 className="font-bebas text-2xl mb-8 border-b-2 border-slate-100 pb-3 text-slate-900 tracking-widest uppercase">Itens Avaliados</h3>
               <div className="space-y-1">
                  {checklist.sections.map((sec, sIdx) => (
                    <div key={sIdx} className="mb-8 last:mb-0">
                       <div className="bg-slate-900 text-white px-4 py-2 rounded-lg font-bold uppercase text-[9px] tracking-widest mb-3">{sec.name}</div>
                       {sec.items.map((item, iIdx) => {
                          const itemIdx = checklist.sections.slice(0, sIdx).reduce((acc, s) => acc + s.items.length, 0) + iIdx;
                          const r = data.respostas[itemIdx];
                          return (
                            <div key={iIdx} className="flex justify-between items-center py-3 border-b border-slate-50 px-2 hover:bg-slate-50 transition-colors">
                               <span className="flex-1 pr-6 text-xs font-medium text-slate-600 leading-tight">{item}</span>
                               <span className={`w-24 text-center text-[9px] font-bold uppercase rounded-lg py-1.5 shadow-sm ${r?.status === 'ok' ? 'bg-green-100 text-green-700' : r?.status === 'nc' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-400'}`}>
                                  {r?.status === 'ok' ? 'CONFORME' : r?.status === 'nc' ? 'NÃO CONF.' : 'N/A'}
                               </span>
                            </div>
                          );
                       })}
                    </div>
                  ))}
               </div>
            </div>

            {/* Signature Area */}
            <div className="mt-24 flex justify-center text-center page-break-inside-avoid">
               <div className="w-80">
                  <div className="h-16 flex items-end justify-center mb-2">
                     {/* Signature placeholder */}
                     <div className="w-full border-b border-slate-900 italic text-slate-300 text-xs tracking-widest uppercase">Assinatura Digital</div>
                  </div>
                  <p className="font-bold text-sm text-slate-900">{data.responsavel}</p>
                  <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest mb-1">{data.cargo || 'Responsável Técnico'}</p>
                  {data.registro && <p className="text-[10px] text-slate-500 font-medium">Reg: {data.registro}</p>}
               </div>
            </div>

            <div className="mt-20 text-center text-[9px] text-slate-300 uppercase font-bold tracking-[.4em] border-t border-slate-50 pt-8">
               Gerado eletronicamente em {dateStr} às {timeStr} via SST Check Pro
            </div>
         </div>
      </div>
    </div>
  );
};

const InfoItem = ({ label, value, highlight = false }: any) => (
  <div>
    <label className="text-[9px] text-slate-400 font-bold uppercase block mb-1.5 tracking-widest">{label}</label>
    <p className={`font-bold text-slate-800 ${highlight ? 'text-red-600' : ''}`}>{value}</p>
  </div>
);

const StatBox = ({ label, val, color }: any) => (
  <div className={`${color} p-6 rounded-2xl text-center shadow-sm`}>
     <div className="text-3xl font-bebas leading-none mb-2">{val}</div>
     <div className="text-[9px] uppercase font-bold tracking-widest opacity-60 leading-tight">{label}</div>
  </div>
);

export default ReportPreview;

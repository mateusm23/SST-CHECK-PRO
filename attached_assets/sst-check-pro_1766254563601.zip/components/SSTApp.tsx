
import React, { useState, useEffect } from 'react';
import { CHECKLISTS } from '../constants';
import { InspectionData, InspectionResponse, ResponseStatus } from '../types';
import ReportPreview from './ReportPreview';

interface SSTAppProps {
  onBack: () => void;
}

const STORAGE_KEY = 'sst_pro_draft';

const SSTApp: React.FC<SSTAppProps> = ({ onBack }) => {
  const [step, setStep] = useState<'menu' | 'form' | 'checklist' | 'report'>('menu');
  const [selectedChecklist, setSelectedChecklist] = useState<string>('');
  const [formData, setFormData] = useState({
    obra: '', cliente: '', responsavel: '', cargo: '', registro: ''
  });
  const [respostas, setRespostas] = useState<Record<number, InspectionResponse>>({});
  const [currentInspection, setCurrentInspection] = useState<InspectionData | null>(null);

  useEffect(() => {
    const draft = localStorage.getItem(STORAGE_KEY);
    if (draft) {
      const { step: dStep, selectedChecklist: dId, formData: dForm, respostas: dResp } = JSON.parse(draft);
      if (confirm('Você tem uma inspeção em andamento. Deseja continuar de onde parou?')) {
        setStep(dStep);
        setSelectedChecklist(dId);
        setFormData(dForm);
        setRespostas(dResp);
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
  }, []);

  useEffect(() => {
    if (step !== 'menu' && step !== 'report') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ step, selectedChecklist, formData, respostas }));
    }
  }, [step, selectedChecklist, formData, respostas]);

  const startChecklist = (id: string) => {
    setSelectedChecklist(id);
    setStep('form');
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.obra || !formData.responsavel) return alert('Preencha os campos obrigatórios!');
    setStep('checklist');
  };

  const setRespostaStatus = (index: number, status: ResponseStatus) => {
    setRespostas(prev => ({
      ...prev,
      [index]: {
        ...(prev[index] || { photos: [], observation: '' }),
        status
      }
    }));
  };

  const handleBatchStatus = (sectionName: string, status: ResponseStatus) => {
    const checklist = CHECKLISTS[selectedChecklist];
    const newRespostas = { ...respostas };
    
    let globalIdx = 0;
    checklist.sections.forEach(sec => {
      sec.items.forEach(() => {
        if (sec.name === sectionName) {
          newRespostas[globalIdx] = {
            ...(newRespostas[globalIdx] || { photos: [], observation: '' }),
            status
          };
        }
        globalIdx++;
      });
    });
    setRespostas(newRespostas);
  };

  const getSectionUniformity = (sectionName: string): ResponseStatus | null => {
    const checklist = CHECKLISTS[selectedChecklist];
    let globalIdx = 0;
    const sectionIndices: number[] = [];
    
    checklist.sections.forEach(sec => {
      sec.items.forEach(() => {
        if (sec.name === sectionName) sectionIndices.push(globalIdx);
        globalIdx++;
      });
    });

    if (sectionIndices.length === 0) return null;
    
    const firstStatus = respostas[sectionIndices[0]]?.status;
    if (!firstStatus) return null;

    const isUniform = sectionIndices.every(idx => respostas[idx]?.status === firstStatus);
    return isUniform ? firstStatus : null;
  };

  const handlePhoto = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setRespostas(prev => ({
          ...prev,
          [index]: {
            ...(prev[index] || { status: 'nc', observation: '' }),
            photos: [...(prev[index]?.photos || []), base64]
          }
        }));
      };
      reader.readAsDataURL(file);
    });
  };

  const finalizeInspection = () => {
    const newInspection: InspectionData = {
      id: Date.now().toString(),
      checklistId: selectedChecklist,
      ...formData,
      data: new Date().toISOString(),
      respostas
    };
    setCurrentInspection(newInspection);
    setStep('report');
    localStorage.removeItem(STORAGE_KEY);
  };

  const checklist = CHECKLISTS[selectedChecklist];
  let itemCounter = 0;

  return (
    <div className="bg-[#F8FAFC] min-h-screen pb-20 text-slate-900">
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-2">
           <button onClick={() => { localStorage.removeItem(STORAGE_KEY); onBack(); }} className="text-[#FFB800] p-2 hover:bg-slate-50 rounded-lg transition-all font-bold">←</button>
           <span className="font-bebas text-xl text-slate-900">SST<span className="text-[#FFB800]">CHECK</span>PRO</span>
        </div>
        <div className="flex items-center gap-3">
           <div className="hidden md:block text-[9px] text-green-500 font-bold uppercase tracking-widest animate-pulse">● Auto-Save Ativo</div>
           <div className="text-[10px] text-slate-400 font-bold uppercase tracking-[.2em] bg-slate-50 px-3 py-1 rounded-full border border-slate-100">MODO CAMPO</div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-6 pt-8">
        {step === 'menu' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="font-bebas text-4xl mb-8 text-slate-900 text-center md:text-left">Nova Inspeção Técnica</h2>
            <div className="grid gap-4">
              {Object.values(CHECKLISTS).map(c => (
                <button key={c.id} onClick={() => startChecklist(c.id)} className="bg-white p-6 rounded-2xl border border-slate-200 hover:border-[#FFD100] transition-all text-left flex justify-between items-center group shadow-sm hover:shadow-lg">
                  <div>
                    <h3 className="font-bold text-lg text-slate-800">{c.title}</h3>
                    <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">{c.nr}</p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-[#FFB800] group-hover:bg-[#FFD100] group-hover:text-[#1A1D23] transition-all">
                    <span className="font-bold text-xl">→</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 'form' && (
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl animate-in zoom-in-95 duration-300">
            <h2 className="font-bebas text-3xl mb-8 text-slate-900">Dados da Identificação</h2>
            <form onSubmit={handleFormSubmit} className="space-y-6">
              <Input label="Obra / Projeto *" placeholder="Ex: Central Park Tower" value={formData.obra} onChange={(v: string) => setFormData({...formData, obra: v})} />
              <Input label="Cliente / Razão Social" placeholder="Ex: Construtora Exemplo S.A." value={formData.cliente} onChange={(v: string) => setFormData({...formData, cliente: v})} />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input label="Técnico Inspetor *" placeholder="Seu nome" value={formData.responsavel} onChange={(v: string) => setFormData({...formData, responsavel: v})} />
                <Input label="Cargo" placeholder="Ex: Eng. de Segurança" value={formData.cargo} onChange={(v: string) => setFormData({...formData, cargo: v})} />
              </div>
              <Input label="Registro Profissional" placeholder="CREA, CAU ou MTE" value={formData.registro} onChange={(v: string) => setFormData({...formData, registro: v})} />
              <button type="submit" className="w-full bg-[#FFD100] text-[#1A1D23] py-5 rounded-2xl font-bold uppercase tracking-widest mt-4 shadow-lg hover:bg-[#E6BC00] active:scale-[0.98] transition-all">
                Abrir Checklists de Campo
              </button>
            </form>
          </div>
        )}

        {step === 'checklist' && (
          <div className="space-y-10">
            <div className="bg-white p-6 rounded-3xl sticky top-20 z-30 shadow-lg border border-slate-100">
               <div className="flex justify-between items-start mb-2">
                 <div>
                    <h2 className="font-bebas text-3xl text-slate-900">{checklist.nr}</h2>
                    <p className="text-slate-400 text-xs font-bold uppercase">{checklist.title}</p>
                 </div>
                 <div className="text-right">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Avanço</div>
                    <div className="text-xl font-bebas text-[#FFB800]">{Math.round((Object.keys(respostas).length / (checklist.sections.reduce((acc, s) => acc + s.items.length, 0))) * 100)}%</div>
                 </div>
               </div>
               <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-[#FFD100] transition-all duration-500" style={{ width: `${(Object.keys(respostas).length / (checklist.sections.reduce((acc, s) => acc + s.items.length, 0))) * 100}%` }}></div>
               </div>
            </div>

            <div className="space-y-12 pb-12">
              {checklist.sections.map((section, sIdx) => {
                const uniformity = getSectionUniformity(section.name);
                return (
                  <div key={sIdx} className="space-y-6">
                     <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                           <div className="flex items-center gap-3">
                              <span className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center text-xs font-bold text-white shrink-0">{sIdx + 1}</span>
                              <div>
                                 <h3 className="font-bebas text-2xl text-slate-800 leading-none">{section.name}</h3>
                                 {uniformity && (
                                   <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full mt-1 inline-block ${uniformity === 'ok' ? 'bg-green-100 text-green-700' : uniformity === 'nc' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'}`}>
                                      ✓ Seção {uniformity === 'ok' ? 'Conforme' : uniformity === 'nc' ? 'Não Conforme' : 'N/A'}
                                   </span>
                                 )}
                              </div>
                           </div>
                           <div className="flex items-center gap-2">
                              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter mr-1 hidden sm:block">Ação em Lote:</span>
                              <div className="flex bg-slate-50 p-1 rounded-xl border border-slate-100">
                                 <button onClick={() => handleBatchStatus(section.name, 'ok')} title="Tudo Conforme" className="w-8 h-8 rounded-lg text-green-600 hover:bg-green-100 flex items-center justify-center transition-colors">✓</button>
                                 <button onClick={() => handleBatchStatus(section.name, 'nc')} title="Tudo Não Conforme" className="w-8 h-8 rounded-lg text-red-600 hover:bg-red-100 flex items-center justify-center transition-colors">✗</button>
                                 <button onClick={() => handleBatchStatus(section.name, 'na')} title="Tudo N/A" className="w-8 h-8 rounded-lg text-slate-400 hover:bg-slate-200 flex items-center justify-center transition-colors">/</button>
                              </div>
                           </div>
                        </div>
                     </div>

                     <div className="space-y-4">
                        {section.items.map((item, iIdx) => {
                          const currentIdx = itemCounter++;
                          const resp = respostas[currentIdx];
                          return (
                            <div key={iIdx} className={`bg-white p-6 rounded-3xl border transition-all shadow-sm ${resp?.status ? 'border-slate-200' : 'border-slate-100 opacity-90'}`}>
                               <p className="font-bold mb-6 text-slate-700 leading-snug text-base">{currentIdx + 1}. {item}</p>
                               <div className="grid grid-cols-3 gap-3 mb-6">
                                  <StatusBtn active={resp?.status === 'ok'} type="ok" onClick={() => setRespostaStatus(currentIdx, 'ok')} />
                                  <StatusBtn active={resp?.status === 'nc'} type="nc" onClick={() => setRespostaStatus(currentIdx, 'nc')} />
                                  <StatusBtn active={resp?.status === 'na'} type="na" onClick={() => setRespostaStatus(currentIdx, 'na')} />
                               </div>

                               {(resp?.status === 'nc' || (resp?.status === 'ok' && resp?.observation)) && (
                                 <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                                    <textarea 
                                      placeholder="Evidências, detalhes ou observações..."
                                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 text-sm focus:outline-none focus:border-[#FFD100] text-slate-800 min-h-[80px] resize-none"
                                      value={resp?.observation || ''}
                                      onChange={e => setRespostas(prev => ({
                                        ...prev,
                                        [currentIdx]: { ...prev[currentIdx], observation: e.target.value }
                                      }))}
                                    />
                                    
                                    <div className="flex items-center gap-4">
                                       <label className="flex-1 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl p-4 text-center cursor-pointer hover:border-[#FFD100]/30 transition-all group">
                                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest group-hover:text-slate-600">📷 Registrar Evidência</span>
                                          <input type="file" multiple accept="image/*" className="hidden" onChange={e => handlePhoto(currentIdx, e)} />
                                       </label>
                                    </div>

                                    {resp?.photos && resp.photos.length > 0 && (
                                      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                                         {resp.photos.map((p, pIdx) => (
                                           <img key={pIdx} src={p} className="w-16 h-16 rounded-xl object-cover border border-slate-200 shadow-sm shrink-0" alt="Evidência" />
                                         ))}
                                      </div>
                                    )}

                                    {resp?.status === 'nc' && (
                                      <div className="bg-red-50 p-6 rounded-2xl border border-red-100">
                                         <div className="text-[9px] font-bold text-red-600 uppercase tracking-widest mb-4">Plano de Ação Corretiva</div>
                                         <div className="grid gap-5">
                                            <div>
                                               <label className="text-[9px] text-slate-400 uppercase font-bold block mb-1">AÇÃO CORRETIVA</label>
                                               <input 
                                                 className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 outline-none focus:border-red-300" 
                                                 value={resp?.actionPlan?.responsible || ''}
                                                 placeholder="O que deve ser regularizado?"
                                                 onChange={e => setRespostas(prev => ({
                                                   ...prev,
                                                   [currentIdx]: { 
                                                     ...prev[currentIdx], 
                                                     actionPlan: { ...(prev[currentIdx].actionPlan || { deadline: '', priority: 'media' }), responsible: e.target.value }
                                                   }
                                                 }))}
                                               />
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                               <div>
                                                  <label className="text-[9px] text-slate-400 uppercase font-bold block mb-1">PRAZO DE ADEQUAÇÃO</label>
                                                  <input type="date" className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 outline-none" />
                                               </div>
                                               <div>
                                                  <label className="text-[9px] text-slate-400 uppercase font-bold block mb-1">CRITICIDADE</label>
                                                  <select className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 outline-none">
                                                     <option value="baixa">BAIXA</option>
                                                     <option value="media" selected>MÉDIA</option>
                                                     <option value="alta">ALTA / CRÍTICA</option>
                                                  </select>
                                               </div>
                                            </div>
                                         </div>
                                      </div>
                                    )}
                                 </div>
                               )}
                            </div>
                          );
                        })}
                     </div>
                  </div>
                );
              })}
            </div>

            <button onClick={finalizeInspection} className="w-full bg-[#1A1D23] text-white py-6 rounded-3xl font-bebas text-3xl uppercase tracking-widest shadow-2xl hover:bg-slate-800 transition-all active:scale-[0.98]">
              ✓ FINALIZAR RELATÓRIO TÉCNICO
            </button>
          </div>
        )}

        {step === 'report' && currentInspection && (
          <ReportPreview data={currentInspection} onNew={() => { localStorage.removeItem(STORAGE_KEY); setStep('menu'); }} />
        )}
      </div>
    </div>
  );
};

const Input = ({ label, value, onChange, placeholder }: any) => (
  <div className="space-y-2">
    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">{label}</label>
    <input type="text" placeholder={placeholder} className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-800 font-medium focus:outline-none focus:border-[#FFD100] transition-all shadow-sm" value={value} onChange={e => onChange(e.target.value)} />
  </div>
);

const StatusBtn = ({ active, type, onClick }: any) => {
  const styles: any = {
    ok: active ? 'bg-green-600 text-white border-green-600 shadow-lg shadow-green-100' : 'bg-white text-green-600 border-slate-200 hover:border-green-200',
    nc: active ? 'bg-red-600 text-white border-red-600 shadow-lg shadow-red-100' : 'bg-white text-red-600 border-slate-200 hover:border-red-200',
    na: active ? 'bg-slate-400 text-white border-slate-400 shadow-lg shadow-slate-100' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'
  };
  const labels: any = { ok: 'CONFORME', nc: 'NÃO CONF.', na: 'N/A' };
  return (
    <button onClick={onClick} className={`py-4 rounded-2xl font-bold text-[10px] uppercase tracking-widest transition-all border-2 flex-1 active:scale-95 ${styles[type]}`}>
      {labels[type]}
    </button>
  );
};

export default SSTApp;

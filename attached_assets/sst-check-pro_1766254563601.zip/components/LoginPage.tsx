
import React, { useState } from 'react';

interface LoginPageProps {
  onLogin: () => void;
  onBack: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, onBack }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Para o MVP, qualquer login é válido
    onLogin();
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-center items-center px-6 relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-2 safety-stripes"></div>
      <div className="absolute -top-24 -right-24 w-64 h-64 bg-[#FFD100]/10 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-slate-200/50 rounded-full blur-3xl"></div>

      <div className="w-full max-w-md animate-in fade-in zoom-in-95 duration-500">
        {/* Logo Area */}
        <div className="flex flex-col items-center mb-10">
          <div className="w-16 h-16 bg-[#FFD100] rounded-2xl flex items-center justify-center font-bold text-[#1A1D23] text-3xl shadow-xl shadow-[#FFD100]/20 mb-4">✓</div>
          <h1 className="font-bebas text-4xl text-slate-900 tracking-wider">SST<span className="text-[#FFB800]">CHECK</span>PRO</h1>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-2">Plataforma de Inspeção Digital</p>
        </div>

        {/* Login Card */}
        <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl border border-slate-100 relative z-10">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Bem-vindo de volta</h2>
          <p className="text-slate-500 text-sm mb-8 font-medium">Acesse sua conta para gerenciar seus checklists de campo.</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block ml-1">E-mail Corporativo</label>
              <input 
                type="email" 
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-800 focus:outline-none focus:border-[#FFD100] transition-all"
                placeholder="seu@email.com.br"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center ml-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Senha</label>
                <button type="button" className="text-[10px] font-bold text-[#FFB800] uppercase hover:underline">Esqueci a senha</button>
              </div>
              <input 
                type="password" 
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-800 focus:outline-none focus:border-[#FFD100] transition-all"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button 
              type="submit"
              className="w-full bg-[#1A1D23] text-white py-5 rounded-2xl font-bold uppercase tracking-widest text-sm shadow-xl hover:bg-slate-800 active:scale-[0.98] transition-all mt-4"
            >
              Entrar na Plataforma
            </button>
          </form>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
            <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest text-slate-300"><span className="bg-white px-4 italic">ou acesse com</span></div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <button onClick={onLogin} className="flex items-center justify-center gap-2 bg-white border border-slate-200 py-3 rounded-xl hover:bg-slate-50 transition-all active:scale-95 shadow-sm">
                <img src="https://www.svgrepo.com/show/355037/google.svg" className="w-4 h-4" alt="Google" />
                <span className="text-[10px] font-bold text-slate-600 uppercase">Google</span>
             </button>
             <button onClick={onLogin} className="flex items-center justify-center gap-2 bg-[#FFD100] border border-[#FFD100] py-3 rounded-xl hover:bg-[#E6BC00] transition-all active:scale-95 shadow-sm">
                <span className="text-[10px] font-bold text-[#1A1D23] uppercase">Modo Demo</span>
             </button>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="mt-8 flex flex-col items-center gap-4">
           <p className="text-slate-500 text-sm font-medium">Não tem uma conta? <button className="text-[#FFB800] font-bold hover:underline">Criar conta grátis</button></p>
           <button onClick={onBack} className="text-slate-400 text-[10px] font-bold uppercase tracking-widest hover:text-slate-600 transition-colors flex items-center gap-2">
             ← Voltar para a Home
           </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;

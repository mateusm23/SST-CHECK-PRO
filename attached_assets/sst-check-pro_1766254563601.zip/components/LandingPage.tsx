
import React from 'react';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <div className="flex flex-col bg-[#F8FAFC]">
      <div className="safety-stripes h-2 w-full"></div>

      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md px-6 py-4 flex justify-between items-center border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#FFD100] rounded-lg flex items-center justify-center font-bold text-[#1A1D23] text-xl shadow-sm">✓</div>
          <span className="font-bebas text-2xl tracking-wider text-[#1A1D23]">SST<span className="text-[#FFB800]">CHECK</span>PRO</span>
        </div>
        <div className="hidden md:flex gap-8 items-center text-xs font-bold uppercase tracking-widest text-slate-500">
          <a href="#funcionalidades" className="hover:text-[#FFB800] transition-colors">Funcionalidades</a>
          <a href="#como-funciona" className="hover:text-[#FFB800] transition-colors">Como Funciona</a>
          <a href="#planos" className="hover:text-[#FFB800] transition-colors">Planos</a>
          <button onClick={onStart} className="bg-[#FFD100] text-[#1A1D23] px-6 py-2 rounded font-bold hover:bg-[#E6BC00] transition-all">Teste Grátis</button>
        </div>
      </nav>

      <section id="hero" className="relative min-h-[85vh] flex items-center px-6 pt-10 overflow-hidden bg-white">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div className="z-10">
            <span className="inline-block bg-[#FFD100]/20 border border-[#FFD100]/30 text-[#1A1D23] px-4 py-1 rounded-full text-[10px] font-bold mb-6 uppercase tracking-widest">🏗️ SEM INSTALAÇÃO • 100% WEB</span>
            <h1 className="font-bebas text-6xl md:text-8xl leading-none mb-6 text-slate-900">SEGURANÇA <br /> EM <span className="text-[#FFB800]">FOCO</span></h1>
            <p className="text-slate-500 text-lg md:text-xl mb-10 max-w-xl leading-relaxed font-medium">Crie checklists das NRs, anexe fotos e gere planos de ação direto no canteiro de obras. Sem papel, sem burocracia.</p>
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <button onClick={onStart} className="bg-[#FFD100] text-[#1A1D23] px-8 py-4 rounded-xl font-bold text-lg uppercase flex items-center justify-center gap-2 hover:bg-[#E6BC00] shadow-xl shadow-[#FFD100]/30 transition-all active:scale-95">🚀 Iniciar 5 Inspeções Grátis</button>
            </div>
          </div>
          <div className="relative flex flex-col gap-6 md:scale-105">
             <div className="bg-white p-5 rounded-2xl border border-red-100 shadow-2xl transform md:-rotate-2">
                <div className="flex justify-between items-center mb-4"><span className="text-[10px] font-bold text-red-600 bg-red-50 px-3 py-1 rounded-full uppercase">Não Conformidade</span></div>
                <div className="flex gap-4"><div className="w-20 h-20 bg-slate-50 rounded-xl flex items-center justify-center text-red-500 border border-red-100 font-bold text-[10px]">FOTO</div><div className="flex-1"><div className="h-4 w-3/4 bg-slate-100 rounded mb-2"></div><div className="h-3 w-full bg-slate-50 rounded"></div></div></div>
             </div>
             <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xl transform md:translate-x-12 md:rotate-2">
                <div className="flex items-center gap-2 mb-4"><div className="w-6 h-6 bg-[#FFD100] rounded flex items-center justify-center font-bold text-[10px]">!</div><span className="text-[10px] font-bold text-slate-900 uppercase">Plano de Ação</span></div>
                <div className="space-y-3"><div className="bg-slate-50 p-3 rounded-lg border border-slate-100"><div className="text-xs font-medium text-slate-700 italic">"Instalar guarda-corpo no 4º pav."</div></div></div>
             </div>
          </div>
        </div>
      </section>

      <section id="funcionalidades" className="bg-slate-50 py-24 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <span className="text-[#FFB800] font-bold text-xs tracking-[.25em] uppercase">Funcionalidades</span>
          <h2 className="font-bebas text-5xl mt-4 mb-16 text-slate-900">Poderoso & Simples</h2>
          <div className="grid md:grid-cols-3 gap-8 text-left">
            <FeatureCard icon="📋" title="NRs Atualizadas" desc="Checklists prontos conforme NR-18, NR-35, NR-12 e mais." />
            <FeatureCard icon="📸" title="Fotos em Tempo Real" desc="Documente evidências direto da câmera do seu celular." />
            <FeatureCard icon="📄" title="PDF Instantâneo" desc="Gere o laudo técnico com a sua logo ainda no campo." />
          </div>
        </div>
      </section>

      <section id="como-funciona" className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="font-bebas text-5xl text-slate-900 mb-20">Como Funciona</h2>
          <div className="grid md:grid-cols-5 gap-8">
            <Step number="1" title="Escolha" desc="Selecione a NR da inspeção." />
            <Step number="2" title="Check" desc="Marque os itens da lista." />
            <Step number="3" title="Foto" desc="Documente as falhas." />
            <Step number="4" title="Ação" desc="Defina o plano corretivo." />
            <Step number="5" title="Relate" desc="Envie o PDF via WhatsApp." />
          </div>
        </div>
      </section>

      <section id="planos" className="bg-slate-50 py-24 px-6 border-t border-slate-100">
        <div className="max-w-7xl mx-auto text-center">
           <span className="text-[#FFB800] font-bold text-xs tracking-[.25em] uppercase">Preços</span>
           <h2 className="font-bebas text-5xl mt-4 mb-16 text-slate-900">Escolha seu Plano</h2>
           <div className="grid md:grid-cols-3 gap-8 items-end">
             <PricingCard title="Gratuito" price="0" features={["1 Inspeção por mês", "PDF Padrão"]} cta="Começar" onCta={onStart} />
             <PricingCard title="Profissional" price="97" featured={true} features={["30 Laudos por mês", "Sua Logo", "Fotos ilimitadas"]} cta="Assinar" onCta={onStart} />
             <PricingCard title="Empresarial" price="247" features={["Laudos Ilimitados", "Múltiplos usuários"]} cta="Contatar" onCta={onStart} />
           </div>
        </div>
      </section>

      <footer className="bg-white border-t border-slate-200 py-12 px-6 text-center">
         <span className="font-bebas text-xl text-slate-900">SST<span className="text-[#FFB800]">CHECK</span>PRO</span>
         <p className="text-slate-400 text-[10px] mt-4 uppercase font-bold tracking-widest">© 2025 Segurança e Tecnologia</p>
      </footer>
    </div>
  );
};

const FeatureCard = ({ icon, title, desc }: any) => (
  <div className="bg-white p-8 rounded-3xl border border-slate-100 hover:border-[#FFD100] transition-all shadow-sm">
    <div className="text-4xl mb-6">{icon}</div>
    <h3 className="text-xl font-bold mb-4 text-slate-900">{title}</h3>
    <p className="text-slate-500 text-sm font-medium">{desc}</p>
  </div>
);

const Step = ({ number, title, desc }: any) => (
  <div className="text-center group">
    <div className="w-16 h-16 bg-white rounded-2xl shadow-lg flex items-center justify-center mx-auto mb-6 border border-slate-50 group-hover:border-[#FFD100] transition-all">
      <span className="font-bebas text-3xl text-[#FFD100]">{number}</span>
    </div>
    <h3 className="font-bold text-lg mb-2 text-slate-900">{title}</h3>
    <p className="text-slate-500 text-xs font-medium px-4">{desc}</p>
  </div>
);

const PricingCard = ({ title, price, features, cta, featured = false, onCta }: any) => (
  <div className={`p-8 rounded-3xl border ${featured ? 'border-[#FFD100] bg-white scale-105 shadow-2xl' : 'border-slate-200'} flex flex-col h-full`}>
    <h3 className="text-2xl font-bold mb-2 text-slate-900">{title}</h3>
    <div className="text-4xl font-bebas text-slate-900 mb-8">R${price}<span className="text-xs text-slate-400 uppercase">/mês</span></div>
    <ul className="space-y-4 mb-10 flex-1 text-xs font-bold text-slate-500">
      {features.map((f: string, i: number) => <li key={i} className="flex items-center gap-3"><span className="text-[#FFB800]">✓</span> {f}</li>)}
    </ul>
    <button onClick={onCta} className={`w-full py-4 rounded-xl font-bold uppercase tracking-widest text-xs transition-all ${featured ? 'bg-[#FFD100] text-[#1A1D23]' : 'bg-slate-100 text-slate-600'}`}>{cta}</button>
  </div>
);

export default LandingPage;

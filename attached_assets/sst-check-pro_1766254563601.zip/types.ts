
export interface ChecklistItem {
  id: string;
  question: string;
  section: string;
}

export interface Section {
  name: string;
  items: string[];
}

export interface ChecklistDefinition {
  id: string;
  title: string;
  nr: string;
  sections: Section[];
}

export type ResponseStatus = 'ok' | 'nc' | 'na';

export interface ActionPlan {
  responsible: string;
  deadline: string;
  priority: 'baixa' | 'media' | 'alta';
}

export interface InspectionResponse {
  status: ResponseStatus;
  observation?: string;
  photos: string[];
  actionPlan?: ActionPlan;
}

export interface InspectionData {
  id: string;
  checklistId: string;
  obra: string;
  cliente: string;
  responsavel: string;
  cargo: string;
  registro: string;
  data: string;
  respostas: Record<number, InspectionResponse>;
}


import { ChecklistDefinition } from './types';

export const CHECKLISTS: Record<string, ChecklistDefinition> = {
  nr18: {
    id: 'nr18',
    title: 'Canteiro de Obras',
    nr: 'NR 18',
    sections: [
      {
        name: 'EPIs - Equipamentos de Proteção Individual',
        items: [
          'Todos os trabalhadores estão utilizando capacete de segurança?',
          'Os trabalhadores estão utilizando calçados de segurança (botinas)?',
          'Óculos de proteção em uso nas atividades que exigem?',
          'Protetores auriculares disponíveis e em uso em áreas ruidosas?',
          'Luvas de proteção adequadas em uso?',
          'EPIs em bom estado de conservação?',
          'Existe controle de entrega de EPIs assinado?'
        ]
      },
      {
        name: 'Proteção Contra Quedas',
        items: [
          'Guarda-corpos instalados em periferias e aberturas?',
          'Guarda-corpos possuem altura mínima de 1,20m?',
          'Aberturas no piso protegidas com tampas ou guarda-corpo?',
          'Trabalhadores em altura utilizam cinto paraquedista?',
          'Existem pontos de ancoragem adequados?'
        ]
      }
    ]
  },
  nr24: {
    id: 'nr24',
    title: 'Condições Sanitárias',
    nr: 'NR 24',
    sections: [
      {
        name: 'Instalações Sanitárias',
        items: [
          'Instalações separadas por sexo?',
          'Proporção de vasos adequada (1:20)?',
          'Vasos funcionando e com papel higiênico?',
          'Higiene das mãos (sabão e toalhas de papel)?'
        ]
      }
    ]
  },
  nr35: {
    id: 'nr35',
    title: 'Trabalho em Altura',
    nr: 'NR 35',
    sections: [
      {
        name: 'Planejamento e Organização',
        items: [
          'Análise de Risco (AR) realizada?',
          'Permissão de Trabalho (PT) emitida?',
          'Trabalhadores capacitados e autorizados?',
          'Sistemas de proteção contra quedas inspecionados?'
        ]
      }
    ]
  },
  nr12: {
    id: 'nr12',
    title: 'Máquinas e Equipamentos',
    nr: 'NR 12',
    sections: [
      {
        name: 'Proteções Fixas e Móveis',
        items: [
          'Zonas de perigo possuem proteções?',
          'Dispositivos de parada de emergência funcionando?',
          'Sinalização de segurança visível?',
          'Manual de instruções disponível?'
        ]
      }
    ]
  }
};

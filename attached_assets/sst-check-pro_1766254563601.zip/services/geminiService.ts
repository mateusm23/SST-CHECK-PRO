
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateSmartActionPlan = async (nonConformity: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Como especialista em SST, sugira um plano de ação curto (máximo 20 palavras) para a seguinte não conformidade: "${nonConformity}".`,
      config: {
        temperature: 0.7,
        maxOutputTokens: 100,
      }
    });
    return response.text || "Corrigir imediatamente conforme normas vigentes.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Realizar adequação imediata.";
  }
};

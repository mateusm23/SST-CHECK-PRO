
import React, { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import SSTApp from './components/SSTApp';
import LoginPage from './components/LoginPage';

const App: React.FC = () => {
  const [view, setView] = useState<'landing' | 'login' | 'app'>('landing');

  useEffect(() => {
    const handlePopState = () => {
      if (view !== 'landing') setView('landing');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [view]);

  const goToLogin = () => {
    window.history.pushState({ view: 'login' }, '');
    setView('login');
    window.scrollTo(0, 0);
  };

  const startApp = () => {
    window.history.pushState({ view: 'app' }, '');
    setView('app');
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen">
      {view === 'landing' && <LandingPage onStart={goToLogin} />}
      {view === 'login' && <LoginPage onLogin={startApp} onBack={() => setView('landing')} />}
      {view === 'app' && <SSTApp onBack={() => setView('landing')} />}
    </div>
  );
};

export default App;
